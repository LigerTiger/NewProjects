import { Component } from '@angular/core';

@Component({
  selector: 'app-infratypeofidmaster',
  templateUrl: './infratypeofidmaster.component.html',
  styleUrls: ['./infratypeofidmaster.component.scss']
})
export class InfratypeofidmasterComponent {

}
