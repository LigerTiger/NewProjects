import { Component } from '@angular/core';

@Component({
  selector: 'app-infrarole',
  templateUrl: './infrarole.component.html',
  styleUrls: ['./infrarole.component.scss']
})
export class InfraroleComponent {

}
