import { Component } from '@angular/core';

@Component({
  selector: 'app-authorizersmaker',
  templateUrl: './authorizersmaker.component.html',
  styleUrls: ['./authorizersmaker.component.scss']
})
export class AuthorizersmakerComponent {

}
