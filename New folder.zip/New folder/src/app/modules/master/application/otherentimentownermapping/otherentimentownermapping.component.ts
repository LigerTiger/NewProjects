import { Component } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OtherentimentownermappingService } from './otherentimentownermapping.service';


@Component({
  selector: 'app-otherentimentownermapping',
  templateUrl: './otherentimentownermapping.component.html',
  styleUrls: ['./otherentimentownermapping.component.scss']
})
export class OtherentimentownermappingComponent {

  myForm = new FormGroup({
    nameType: new FormControl('',Validators.required),
    empAdid: new FormControl('',Validators.required),
    empName: new FormControl('',Validators.required),
    businessUnit: new FormControl('',Validators.required),
    corporateDesignation: new FormControl(''),
    functionalDesignation: new FormControl(''),
    isActive: new FormControl('')
    
});
  constructor(private fb: FormBuilder, private otherentimentownermappingService: OtherentimentownermappingService) {}

  ngOnInit() {
  }

  // onVerify(){
  // alert("on verify")
  // }
  
  // fetchData() {
  //   this.otherentimentownermappingService.getData().subscribe(
  //     (data) => {
  //       this.myForm.patchValue({
  //         nameType: data.nameType,
  //         empAdid: data.empAdid,
  //         // Update with other form controls
  //       });
  //     },
  //     (error: any) => {
  //       console.error('Error fetching data:', error);
  //     }
  //   );
  // }

  onSubmit(){
    console.log(this.myForm.value)
  }

  resetForm(){
    alert("on reset")
    this.myForm.reset();
  }

  update(){
    alert("on update")
  }
}
