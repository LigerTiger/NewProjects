import { Component } from '@angular/core';

@Component({
  selector: 'app-accesscontrol',
  templateUrl: './accesscontrol.component.html',
  styleUrls: ['./accesscontrol.component.scss']
})
export class AccesscontrolComponent {

}
