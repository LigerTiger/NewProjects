import { Component } from '@angular/core';

@Component({
  selector: 'app-exceptionapprovermaster',
  templateUrl: './exceptionapprovermaster.component.html',
  styleUrls: ['./exceptionapprovermaster.component.scss']
})
export class ExceptionapprovermasterComponent {

}
