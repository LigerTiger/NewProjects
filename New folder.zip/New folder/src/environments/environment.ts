export const environment = {
    production: false,
    url : "https://api.devapp.360tf.trade",
    admin_url:"https://api.devapp.360tf.trade/admin",
    refreshTime:18000
  };