export const environment = {
    production: false,
    url : "https://api.devapp.360tf.trade",
    admin_url:"https://api.devapp.360tf.trade/admin",
    refreshTime:18000
  };
/*
pass values in sec
for 10 sec pass 10
for 5 hrs  pass 18000   // (5*60*60 = 18000)//
*/

